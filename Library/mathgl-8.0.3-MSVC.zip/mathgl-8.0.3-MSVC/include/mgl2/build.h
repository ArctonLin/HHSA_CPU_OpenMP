#ifndef _MGL_BUILD_H_
#define _MGL_BUILD_H_

#define MGL_BUILD_DATE	"2025-07-17T14:28:37Z"

#endif
